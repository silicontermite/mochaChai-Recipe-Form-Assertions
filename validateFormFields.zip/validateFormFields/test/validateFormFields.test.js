var assert = require('chai').assert;	//Chai assertion library
var myMethods= require('../app/validateFormFields');
var validateRecipeName = myMethods.validateRecipeName;
var validateIngredientName = myMethods.validateIngredientName;
var validateInstructions= myMethods.validateInstructions;

describe("Testing Recipe Name", function(){	

	it("Recipe names with 3 letters, no leading or trailing spaces should pass", function(){
		assert.isTrue(validateRecipeName('Fud'));
	});	
	
	it("Recipe names with 3 alphanumerics, 1 space in the middle, and no leading or trailing spaces should pass", function(){
		assert.isTrue(validateRecipeName('1 I'));
	});

	it("Recipe names with 2 alphanumerics, separated by 29 spaces, and no leading or trailing spaces should pass", function(){
		assert.isTrue(validateRecipeName('A                             7'));
	});		
		
	it("Recipe names with 31 letters, no leading or trailing spaces should pass", function(){
		assert.isTrue(validateRecipeName('abcdefghijklmnopqrstuvwxyzabcde'));
	});	
	
	it("Recipe names with 31 numbers, no leading or trailing spaces should pass", function(){
		assert.isTrue(validateRecipeName('1234567890123456789012345678901'));
	});
		
	it("Recipe names with 31 alphanumerics, no leading or trailing spaces should pass", function(){
		assert.isTrue(validateRecipeName('12345abcdefghijklmnopqrstuvwxyz'));
	});
	
	it("Recipe names with 2 letters, no leading or trailing spaces should fail", function(){
		assert.isFalse(validateRecipeName('Fd'));
	});		
	
	it("Recipe names with 32 characters, no leading or trailing spaces should fail", function(){
		assert.isFalse(validateRecipeName('abcdefghijklmnopqrstuvwxyzabcdef'));
	});	
	it("Recipe names with a space at the beginning should fail", function(){
		assert.isFalse(validateRecipeName(' Food'));
	});	
	
	it("Recipe names with a space at the end should fail", function(){
		assert.isFalse(validateRecipeName('Food '));
	});	
	
	it("Recipe names with any non-alphanumerics should fail", function(){
		assert.isFalse(validateRecipeName('Food=ddd'));
	});	
});


describe("Testing Ingedient Name", function(){	

	it("Ingredient names with 3 periods, no leading or trailing spaces should pass", function(){
		assert.isTrue(validateIngredientName('...'));
	});	
	
	it("Ingredient names with 2 periods with a space in the middle, and no leading or trailing spaces should pass", function(){
		assert.isTrue(validateIngredientName('. .'));
	});

	it("Ingredient names with 2 periods, separated by 29 spaces, and no leading or trailing spaces should pass", function(){
		assert.isTrue(validateIngredientName('.                             .'));
	});		
		
	it("Ingredient names with 31 letters, no leading or trailing spaces should pass", function(){
		assert.isTrue(validateIngredientName('abcdefghijklmnopqrstuvwxyzabcde'));
	});	
	
	it("Ingredient names with 31 numbers, no leading or trailing spaces should pass", function(){
		assert.isTrue(validateIngredientName('1234567890123456789012345678901'));
	});
		
	it("Ingredient names with 31 alphanumerics,periods,spaces and no leading or trailing spaces should pass", function(){
		assert.isTrue(validateIngredientName('123 ..  .. g  jklmnopqrst..wxyz'));
	});
	
	it("Ingredient names with 2 letters, no leading or trailing spaces should fail", function(){
		assert.isFalse(validateIngredientName('oo'));
	});		
	
	it("Ingredient names with 32 characters, no leading or trailing spaces should fail", function(){
		assert.isFalse(validateIngredientName('abcdefghijklmnopqrstuvwxyzabcdef'));
	});	
	it("Ingredient names with a space at the beginning should fail", function(){
		assert.isFalse(validateIngredientName(' Food'));
	});	
	
	it("Ingredient names with a space at the end should fail", function(){
		assert.isFalse(validateIngredientName('Food '));
	});	
	
	it("Ingredient names with any non-alphanumerics, except periods and spaces, should fail", function(){
		assert.isFalse(validateIngredientName('Food!ddd'));
	});		

});
/**/

describe("Testing Instructions", function(){	

		it("Instructions with 3 \"minus symbols\", no leading or trailing spaces should pass", function(){
		assert.isTrue(validateInstructions('---'));
	});	
	
	it("Instructions with 2 degree symbols ° with a space in the middle, and no leading or trailing spaces should pass", function(){
		assert.isTrue(validateInstructions('° °'));
	});

	it("Instructions with 2 commas, separated by 251 spaces, and no leading or trailing spaces should pass \( this test actually broke mocha-chai,possibly line wrap, but was tested externally https://regex101.com/ )", function(){
		assert.isTrue(validateInstructions(',                                                    ,'));
	});		
		
	it("Instructions with 253 letters, no leading or trailing spaces should pass", function(){
		assert.isTrue(validateInstructions('abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrs'));
	});	
	
	it("Instructions with 253 numbers, no leading or trailing spaces should pass", function(){
		assert.isTrue(validateInstructions('1234567890123456789012345678901123456789012345678901234567890112345678901234567890123456789011234567890123456789012345678901123456789012345678901234567890112345678901234567890123456789011234567890123456789012345678901123456789012345678901234567890123456'));
	});
	
	it("Instructions with 253 non-alphanumerics and no leading or trailing spaces should pass", function(){
		assert.isTrue(validateInstructions('., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-.'));
	});
		
	it("Instructions with 254 non-alphanumerics and no leading or trailing spaces should fail", function(){
		assert.isFalse(validateInstructions('., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-., °()-.,'));
	});
	
	it("Instructions with 2 letters, no leading or trailing spaces should fail", function(){
		assert.isFalse(validateInstructions('oo'));
	});		
	
	it("Instructions with 254 letters, no leading or trailing spaces should fail", function(){
		assert.isFalse(validateInstructions('abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrst'));
	});	
	it("Instructions with a space at the beginning should fail", function(){
		assert.isFalse(validateInstructions(' Food'));
	});	
	
	it("Instructions with a space at the end should fail", function(){
		assert.isFalse(validateInstructions('Food '));
	});	
	
	it("Instructions with any non-alphanumerics except should fail", function(){
		assert.isFalse(validateInstructions('Food!ddd'));
	});	
	
	it("Instructions with any non-alphanumerics, except \".,'space',°,'comma',\(,\),and - \", should fail", function(){
		assert.isFalse(validateInstructions('..F..ood*ddd..'));
	});	
	
	it("Instructions with backticks should fail", function(){
		assert.isFalse(validateInstructions('a`a'));
	});	
	
	it("Instructions with quotes should fail", function(){
		assert.isFalse(validateInstructions('a"a'));
	});	
	it("Instructions with single quotes should fail", function(){
		assert.isFalse(validateInstructions('a\'a'));
	});	
	it("Instructions with semicolon should fail", function(){
		assert.isFalse(validateInstructions('a;a'));
	});	
	it("Instructions with backslash should fail", function(){
		assert.isFalse(validateInstructions('a\\a'));
	});
	it("Instructions with braces should fail", function(){
		assert.isFalse(validateInstructions('{a}'));
	});
	it("Instructions enclosed in parenthesis should pass", function(){
		assert.isTrue(validateInstructions('(function (e))'));
	});
});

	//end "Testing Input Required"

/*
describe("Testing Valid Phone Number", function(){
	
	it("Input is required");
	it("Input must be numeric");
	it("Input must be integers");
	it("Input must be 10 numbers");
	
});
*/