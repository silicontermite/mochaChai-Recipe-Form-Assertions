

/*          */
var isInput= function(inValue){
	inValue += "";	//turns all inValues into strings
	//inValue = inValue.trim();
	if(inValue == "" || inValue == 'null' || inValue == 'undefined'){
		return false;
	}
	return inValue;
};

/* */
var validateRecipeName= function(inValue){
	inValue=(isInput(inValue));	
	var recipeNamePattern = new RegExp(/^(?=[a-zA-Z 0-9]{3,31}$)[^ ][a-zA-Z0-9 ?]*[^ ]$/);	
	if(recipeNamePattern.test(inValue)!= true || inValue==false){
		return false;
	}
	return true;
}
/*^(?=[\\.a-zA-Z 0-9]{3,31}$)[^ ][\\.a-zA-Z0-9 ?]*[^ ]$*/
var validateIngredientName= function(inValue){
	inValue=(isInput(inValue));	
	var recipeNamePattern = new RegExp(/^(?=[\\.a-zA-Z 0-9]{3,31}$)[^ ][\\.a-zA-Z0-9 ?]*[^ ]$/);	
	if(recipeNamePattern.test(inValue)!= true || inValue==false){
		return false;
	}
	return true;
}
			
var validateInstructions= function(inValue){    
    //test for input existing not empty etc.
    inValue = isInput(inValue);
    var InstructionPattern = new RegExp(/^(?=[\.a-zA-Z 0-9°,\)\(\-]{3,253}$)[^ ][\-\)\(,°\.a-zA-Z0-9 ?]*[^ ]$/);
    /* if passing the regex pattern test for input, test for an actual existing zip code for the table above is used*/
  
    if(InstructionPattern.test(inValue)!= true || inValue==false){
		return false;
	}
	return true;
};

module.exports = {
    validateRecipeName, validateIngredientName, validateInstructions
}
